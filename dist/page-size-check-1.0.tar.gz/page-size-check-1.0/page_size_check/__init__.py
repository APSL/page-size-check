__author__ = 'Carlos Salom'
__email__ = 'csalom@apsl.net'
__version__ = '1.0'
