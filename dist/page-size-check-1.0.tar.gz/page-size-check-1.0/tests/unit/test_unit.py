import pytest


@pytest.mark.unit_test
def test_true():
    assert True
